# Author: Hoa Vo & Misako Ueshima
# RGBColor
